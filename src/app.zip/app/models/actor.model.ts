export interface Actor {
  name: string;
  city: string;
  salary?: number;
}
